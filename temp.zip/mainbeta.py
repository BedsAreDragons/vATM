import pygame
import sys
import math
import random

# Initialize Pygame
pygame.init()

# Set up the screen
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
screen_width, screen_height = pygame.display.get_surface().get_size()
pygame.display.set_caption("Aircraft Above London")

# Load the radar screen background image
background_image = pygame.image.load("EGTT_CTR4.jpg")  # Replace with the actual image path
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

# London boundaries
london_bounds = {'min_latitude': 49.87729502870266, 'max_latitude': 53.375740,  'min_longitude': -8.032269062481339, 'max_longitude': 2.665598}

# Aircraft data
aircraft_list = [
    {'callsign': 'ABC123', 'latitude': 51.5, 'longitude': 0.5, 'altitude': 30000, 'heading': 150, 'speed': 500,
     'departure': 'JFK', 'arrival': 'LHR', 'flight_plan': 'DIRECT', 'cruise_altitude': 35000, 'squawk': '1234'},
    {'callsign': 'XYZ789', 'latitude': 53.0, 'longitude': 0.8, 'altitude': 35000, 'heading': 270, 'speed': 600,
     'departure': 'LHR', 'arrival': 'JFK', 'flight_plan': 'VIA UL9', 'cruise_altitude': 37000, 'squawk': '7700'},
]



# Function to convert coordinates to screen position
def convert_to_screen(latitude, longitude):
    x = int((longitude - london_bounds['min_longitude']) / (london_bounds['max_longitude'] - london_bounds['min_longitude']) * screen_width)
    y = int((london_bounds['max_latitude'] - latitude) / (london_bounds['max_latitude'] - london_bounds['min_latitude']) * screen_height)
    return x, y

# Function to display aircraft on the screen
def display_aircraft(screen, aircraft_list):
    # Blit the background image onto the screen
    screen.blit(background_image, (0, 0))

    # Draw radar scope circles in the middle
    center_x, center_y = screen_width // 2, screen_height // 2
   # pygame.draw.circle(screen, (255, 255, 255), (center_x, center_y), 50, 2)
   # pygame.draw.circle(screen, (255, 255, 255), (center_x, center_y), 100, 2)
   # pygame.draw.circle(screen, (255, 255, 255), (center_x, center_y), 150, 2)
   # pygame.draw.circle(screen, (255, 255, 255), (center_x, center_y), 200, 2)
    #pygame.draw.circle(screen, (255, 255, 255), (center_x, center_y), 250, 2)

    font = pygame.font.Font(None, 24)

    for aircraft in aircraft_list:
        # Convert coordinates to screen position
        screen_x, screen_y = convert_to_screen(aircraft['latitude'], aircraft['longitude'])

        # Draw the square at the aircraft's position
        pygame.draw.rect(screen, (255, 255, 255), (screen_x - 10, screen_y - 10, 20, 20))

        # Draw the corrected heading line
        rad_heading = math.radians(aircraft['heading'] - 90)  # Adjusting to start from the top (North)
        line_length = 30
        end_pos = (screen_x + int(line_length * math.cos(rad_heading)),
                   screen_y + int(line_length * math.sin(rad_heading)))
        pygame.draw.line(screen, (255, 255, 255), (screen_x, screen_y), end_pos, 2)

        # Display additional information
        info_text = f"{aircraft['callsign']}  {aircraft['altitude']}"
        text_render = font.render(info_text, True, (255, 255, 255))
        text_rect = text_render.get_rect(midtop=(screen_x + 70, screen_y + 15))  # Adjusted position
        screen.blit(text_render, text_rect)

        # Display emergency indicator for squawking 7700, 7500, 7600
        if aircraft['squawk'] in ['7700', '7500', '7600']:
            pygame.draw.circle(screen, (255, 0, 0), (screen_x + 10, screen_y - 10), 10)

    pygame.display.flip()  # Update the display

# Function to display detailed information about an aircraft in a new window
def display_aircraft_info(aircraft):
    font = pygame.font.Font(None, 32)

    info_screen = pygame.display.set_mode((1200, 600), pygame.FULLSCREEN)
    pygame.display.set_caption(f"Aircraft Info - {aircraft['callsign']}")
    running = True

    ssr_code_generated = False

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # Check if the mouse click is on the "REQ SSR IFR" button
                generate_ssr_button = pygame.Rect(900, 20, 200, 50)
                if generate_ssr_button.collidepoint(event.pos):
                    # Generate SSR code and update the screen
                    aircraft['squawk'] = generate_ssr_code(aircraft)
                    ssr_code_generated = True

        # Display detailed information
        info_text = [
            f"Departure: {aircraft['departure']}",
            f"Arrival: {aircraft['arrival']}",
            f"Flight Plan: {aircraft['flight_plan']}",
            f"Cruise Altitude: {aircraft['cruise_altitude']}",
            f"Current Altitude: {aircraft['altitude']}",
            f"Current Heading: {aircraft['heading']}",
            f"Speed: {aircraft['speed']}",
            f"Squawk: {aircraft['squawk']}",
        ]

        # Generate SSR code button
        generate_ssr_button = pygame.Rect(900, 20, 200, 50)
        pygame.draw.rect(info_screen, (0, 255, 0), generate_ssr_button)
        generate_ssr_text = font.render("REQ SSR IFR", True, (0, 0, 0))
        generate_ssr_text_rect = generate_ssr_text.get_rect(center=generate_ssr_button.center)
        info_screen.blit(generate_ssr_text, generate_ssr_text_rect)

        # Display SSR code if generated
        if ssr_code_generated:
            ssr_text = f"Generated SSR Code: {aircraft['squawk']}"
            ssr_render = font.render(ssr_text, True, (255, 255, 255))
            ssr_rect = ssr_render.get_rect(topleft=(700, 100))
            info_screen.blit(ssr_render, ssr_rect)

        # Display information text
        for i, text in enumerate(info_text):
            text_render = font.render(text, True, (255, 255, 255))
            text_rect = text_render.get_rect(topleft=(20, 20 + i * 40))
            info_screen.blit(text_render, text_rect)

        pygame.display.flip()

    # Do not quit Pygame and exit here to keep the main window open

# Function to generate SSR code
def generate_ssr_code(aircraft):
    # Define SSR code ranges
    ssr_ranges = [
        (300, 777),
        (1001, 1077),
        (1101, 1177),
        (1201, 1777),
        (3001, 3777),
        (4001, 4777),
        (6001, 6777),
    ]

    # Check if the current squawk is an emergency code
    emergency_squawks = ['7700', '7500', '7600']
    if aircraft['squawk'] in emergency_squawks:
        return f"EMERGENCY: {aircraft['squawk']}"

    # Generate a random SSR code within the specified ranges
    ssr_code = random.choice([f"{random.randint(start, end):04}" for start, end in ssr_ranges])
    return ssr_code


running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # Check if the mouse click is on an aircraft
            for aircraft in aircraft_list:
                screen_x, screen_y = convert_to_screen(aircraft['latitude'], aircraft['longitude'])
                if screen_x - 10 <= event.pos[0] <= screen_x + 10 and screen_y - 10 <= event.pos[1] <= screen_y + 10:
                    # Display detailed information in a new window
                    display_aircraft_info(aircraft)

    # Display the aircraft on the screen
    display_aircraft(screen, aircraft_list)

    # Simulate real-time updates by waiting for a short duration
    pygame.time.delay(10)

# Quit Pygame and exit
pygame.quit()
sys.exit()
